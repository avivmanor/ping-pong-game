
//creating the game canvas:
var game= document.getElementById("gameCanvas");
game.height = 0.95*window.innerHeight;
game.width = 0.99*window.innerWidth;
var gamectx = game.getContext("2d");

var startTime=Date.now();

//function to set the stopwatch
function timeToString() {
    let time = Date.now()-startTime;
    let diffInHrs = time / 3600000;
    let hh = Math.floor(diffInHrs);
  
    let diffInMin = (diffInHrs - hh) * 60;
    let mm = Math.floor(diffInMin);
  
    let diffInSec = (diffInMin - mm) * 60;
    let ss = Math.floor(diffInSec);
  
    let diffInMs = (diffInSec - ss) * 60;
    let ms = Math.floor(diffInMs);
  
  
    let formattedMM = mm.toString().padStart(2, "0");
    let formattedSS = ss.toString().padStart(2, "0");
    let formattedMS = ms.toString().padStart(2, "0");
  
    return `${formattedMM}:${formattedSS}:${formattedMS}`;
  }  

//draws the stopwatch
gamectx.font = "30px Arial";
gamectx.textAlign = "center";
gamectx.fillText(timeToString(), game.width/2, game.height/8);

//creating the ball and two bats inside the canvas:
gamectx.beginPath();
gamectx.fillStyle = 'red';
gamectx.strokeStyle = 'red';
gamectx.arc(95, 50, 40, 0, 2 * Math.PI);
gamectx.fill();
gamectx.stroke();
gamectx.fillStyle = 'blue';
gamectx.fillRect(0,0,20,200);
gamectx.fillStyle = 'green';
gamectx.fillRect(game.width-20,0,20,200);

//function to clear all objects inside the canvas
function clear(){
    gamectx.clearRect(0, 0, game.width, game.height);
}

//delta will determine the distance the left bat will move every up and down pressed
var delta=0;
var batY=0;

//flag for ending the game:
var flag=0;

//creates the ball location and movment
var ball = {
    x: 95,
    y: 50,
    // if i want the velocity to be random every game:
    //velX: (Math.random() * 15 + 5) * (Math.floor(Math.random() * 2) || -1),
    //velY: (Math.random() * 15 + 5) * (Math.floor(Math.random() * 2) || -1)
    //constnat velocity:
    velX:3,
    velY:3,
}

//responsible for moving the right bat according to the ball
var rightY=1;

//function that creates the objects in the game canvas in their new location
function updateObject(global){
    //if the player lost the game, it doesnt fill the canvas
    if(flag==1) {return;}
    var self=global;
    //deals with the ball:
        //increase the velocity:
        if(ball.velX>0) {ball.velX+=0.001;}
        else {ball.velX-=0.001;}
        if(ball.velY>0){ball.velY+=0.001;}
        else {ball.velY-=0.001;}
        //checkes if it hits the walls:
    if(ball.x+40>=game.width-20){
        ball.velX*=-1;
        if(ball.y>game.height-200){
            rightY=game.height-200;
        }
        else if(ball.y<100){
			rightY=0;}
			else {
            rightY=ball.y-100;
        }
    }
    if(ball.y+40>=game.height || ball.y-40<=0){
        ball.velY*=-1;
    }
        //checkes if it hits the left bat:
    if(ball.x-40<=20 && (ball.y>=self.batY && ball.y<=self.batY+200)){
        ball.velX*=-1;
    }
        //if it doesnt - end the game, the player lost
    else if(ball.x-40<=20){
        flag=1;
        game.remove();
        var heading = document.createElement("h1");
        var node = document.createTextNode("YOU LOST");
        heading.appendChild(node);
        var element = document.getElementById("head");
        element.appendChild(heading);
    }
    gamectx.font = "30px Arial";
    gamectx.fillStyle = "black"
    gamectx.textAlign = "center";
    gamectx.fillText(timeToString(), game.width/2, game.height/8);
    ball.x += ball.velX;        
    ball.y += ball.velY;
    gamectx.beginPath();
    gamectx.fillStyle = 'red';
    gamectx.strokeStyle = 'red';
    gamectx.arc(ball.x, ball.y, 40, 0, 2 * Math.PI);    
    gamectx.fill();
    gamectx.stroke();
    //deals with the left bat:
    //checkes if the bat got to the start or the end of the page, if so it prevents him from moving further
    if((self.batY<=1 && delta<0) || ((self.batY>=(game.height-200))&&delta>0)){
        delta=0;
    }
    self.batY+=delta;
    self.delta=0;
    gamectx.fillStyle = 'blue';
    gamectx.fillRect(0,self.batY,20,200);
    //deals with right bat:
    gamectx.fillStyle = 'green';
    gamectx.fillRect(game.width-20,rightY,20,200);
    
}

//updates the canvas and creates motion with clear and create
function updateGame(){
    clear();
    updateObject(window);
}

//repeat update game to imitate motion on the screen
setInterval(updateGame,20);

//listenner to the keyboard arrows:
window.addEventListener("keydown", moveSomething, false);


//checkes if up or down was pressed and determines the distance the bat will make
function moveSomething(e) {
    switch(e.keyCode) {
        case 38:
            // up key pressed
            delta=-50;
            console.log("up pressed");
            break;
        case 40:
            // down key pressed
            delta=50;
            console.log("down pressed");
            break;  
    }   
} 


